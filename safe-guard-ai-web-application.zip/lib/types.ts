// Shared domain types for SafeGuard AI.
// These mirror the shape of the future backend API responses so that
// demo data can be swapped for real API data without changing the UI.

export type Severity = 'Safe' | 'Suspicious' | 'High' | 'Critical'

export type IncidentCategory =
  | 'Safe'
  | 'Threat'
  | 'Harassment'
  | 'Suspicious'

export type RecommendedAction =
  | 'protect'
  | 'preserve'
  | 'report'
  | 'none'

/** Response returned by POST /api/analyze */
export interface AnalysisResult {
  category: IncidentCategory
  severity: Severity
  /** 0..1 model confidence */
  confidence: number
  explanation: string
  indicators: string[]
  recommendedActions: RecommendedAction[]
}

export type IntegrityStatus = 'verified' | 'pending' | 'unverified'

export interface AuditEvent {
  label: string
  timestamp: string
}

/** A preserved incident. Mirrors GET /api/evidence/{id} */
export interface EvidenceRecord {
  id: string
  category: IncidentCategory
  severity: Severity
  createdAt: string
  message: string
  analysis: AnalysisResult
  /** Demo SHA-256 style hash. Not a real cryptographic guarantee. */
  hash: string
  integrity: IntegrityStatus
  audit: AuditEvent[]
  protected: boolean
  /** true = generated locally for the demo, not from a real backend */
  demo: boolean
}

export interface ActivityEntry {
  id: string
  title: string
  category: IncidentCategory
  severity: Severity
  time: string
  status: string
}
