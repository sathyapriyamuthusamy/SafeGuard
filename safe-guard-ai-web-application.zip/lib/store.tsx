'use client'

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import type { AnalysisResult, EvidenceRecord } from './types'
import { seedEvidence } from './demo-data'
import { createEvidence } from './api'

// In-memory demo store. This holds session state for the frontend
// demonstration only — it is NOT a database and does not persist. When the
// backend is connected, replace these actions with data fetched via lib/api.ts
// (e.g. using SWR).

interface StoreValue {
  evidence: EvidenceRecord[]
  getEvidence: (id: string) => EvidenceRecord | undefined
  preserveEvidence: (input: {
    message: string
    analysis: AnalysisResult
  }) => Promise<EvidenceRecord>
  setProtected: (id: string, value: boolean) => void
  removeEvidence: (id: string) => void
}

const StoreContext = createContext<StoreValue | null>(null)

export function StoreProvider({ children }: { children: ReactNode }) {
  const [evidence, setEvidence] = useState<EvidenceRecord[]>(seedEvidence)

  const getEvidence = useCallback(
    (id: string) => evidence.find((e) => e.id === id),
    [evidence],
  )

  const preserveEvidence = useCallback(
    async (input: { message: string; analysis: AnalysisResult }) => {
      const record = await createEvidence(input)
      setEvidence((prev) => [record, ...prev])
      return record
    },
    [],
  )

  const setProtected = useCallback((id: string, value: boolean) => {
    setEvidence((prev) =>
      prev.map((e) => (e.id === id ? { ...e, protected: value } : e)),
    )
  }, [])

  const removeEvidence = useCallback((id: string) => {
    setEvidence((prev) => prev.filter((e) => e.id !== id))
  }, [])

  const value = useMemo(
    () => ({
      evidence,
      getEvidence,
      preserveEvidence,
      setProtected,
      removeEvidence,
    }),
    [evidence, getEvidence, preserveEvidence, setProtected, removeEvidence],
  )

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export function useStore() {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error('useStore must be used within StoreProvider')
  return ctx
}
