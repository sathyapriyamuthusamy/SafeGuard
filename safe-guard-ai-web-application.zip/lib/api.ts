import type { AnalysisResult, EvidenceRecord } from './types'
import { demoAnalyze, demoHash } from './demo-data'

// ---------------------------------------------------------------------------
// Service layer
// ---------------------------------------------------------------------------
// This is the ONLY place that should know how to talk to the backend. UI
// components import these functions instead of calling fetch directly, so the
// demo implementation can be replaced with real network calls without touching
// any screens.
//
// Future backend endpoints:
//   POST   /api/analyze
//   POST   /api/evidence
//   GET    /api/evidence
//   GET    /api/evidence/{id}
//   POST   /api/evidence/{id}/verify
//   POST   /api/evidence/{id}/report
//
// When NEXT_PUBLIC_API_URL is set, swap the demo branches for real fetch calls.
// ---------------------------------------------------------------------------

export const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? ''
export const IS_BACKEND_CONNECTED = API_BASE.length > 0

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

/** POST /api/analyze */
export async function analyzeMessage(message: string): Promise<AnalysisResult> {
  if (IS_BACKEND_CONNECTED) {
    const res = await fetch(`${API_BASE}/api/analyze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    })
    if (!res.ok) throw new Error('Analysis request failed')
    return (await res.json()) as AnalysisResult
  }

  // Demo: simulate model latency and return heuristic output.
  await delay(1600)
  return demoAnalyze(message)
}

/**
 * POST /api/evidence
 * Creates a preserved evidence record from a message + analysis.
 * In demo mode the hash is generated locally and is NOT a real cryptographic
 * verification.
 */
export async function createEvidence(input: {
  message: string
  analysis: AnalysisResult
}): Promise<EvidenceRecord> {
  if (IS_BACKEND_CONNECTED) {
    const res = await fetch(`${API_BASE}/api/evidence`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    if (!res.ok) throw new Error('Failed to preserve evidence')
    return (await res.json()) as EvidenceRecord
  }

  await delay(900)
  const now = new Date()
  const id = `SG-${now.getFullYear()}-${String(
    Math.floor(10000 + Math.random() * 89999),
  ).slice(0, 5)}`
  const createdAt = now.toISOString()
  return {
    id,
    category: input.analysis.category,
    severity: input.analysis.severity,
    createdAt,
    message: input.message,
    analysis: input.analysis,
    hash: demoHash(id + input.message),
    integrity: 'verified',
    protected: true,
    demo: true,
    audit: [
      { label: 'Message analyzed', timestamp: createdAt },
      { label: 'Evidence preserved', timestamp: createdAt },
      { label: 'Hash generated', timestamp: createdAt },
      { label: 'Record stored', timestamp: createdAt },
      { label: 'Integrity verified', timestamp: createdAt },
    ],
  }
}

/** POST /api/evidence/{id}/verify */
export async function verifyEvidence(record: EvidenceRecord): Promise<boolean> {
  if (IS_BACKEND_CONNECTED) {
    const res = await fetch(`${API_BASE}/api/evidence/${record.id}/verify`, {
      method: 'POST',
    })
    if (!res.ok) throw new Error('Verification failed')
    const data = (await res.json()) as { verified: boolean }
    return data.verified
  }

  await delay(1200)
  // Demo: recompute the local hash and compare.
  return demoHash(record.id + record.message) === record.hash
}
