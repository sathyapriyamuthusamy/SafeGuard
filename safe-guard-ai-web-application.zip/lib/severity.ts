import type { Severity } from './types'

// Presentation metadata for each severity level. Uses the status design
// tokens defined in globals.css so colors stay consistent everywhere.
export const severityMeta: Record<
  Severity,
  {
    label: string
    // Tailwind classes for a soft badge/surface
    surface: string
    text: string
    dot: string
    border: string
    // Solid accent for icons / bars
    accent: string
  }
> = {
  Safe: {
    label: 'Safe',
    surface: 'bg-safe-surface',
    text: 'text-safe-foreground',
    dot: 'bg-safe',
    border: 'border-safe/25',
    accent: 'text-safe',
  },
  Suspicious: {
    label: 'Suspicious',
    surface: 'bg-suspicious-surface',
    text: 'text-suspicious-foreground',
    dot: 'bg-suspicious',
    border: 'border-suspicious/30',
    accent: 'text-suspicious',
  },
  High: {
    label: 'High Risk',
    surface: 'bg-high-surface',
    text: 'text-high-foreground',
    dot: 'bg-high',
    border: 'border-high/30',
    accent: 'text-high',
  },
  Critical: {
    label: 'Critical',
    surface: 'bg-critical-surface',
    text: 'text-critical-foreground',
    dot: 'bg-critical',
    border: 'border-critical/40',
    accent: 'text-critical',
  },
}
