import type {
  AnalysisResult,
  ActivityEntry,
  EvidenceRecord,
  Severity,
} from './types'

// ---------------------------------------------------------------------------
// DEMO ONLY
// Everything in this file is illustrative sample content used for the frontend
// demonstration. None of it represents a real AI model output, a real database
// record, or a real cryptographic verification. When the backend is connected,
// the service layer in lib/api.ts should return this shape from real endpoints.
// ---------------------------------------------------------------------------

/** Produce a deterministic-looking demo SHA-256 style hash string. */
export function demoHash(seed: string): string {
  const chars = '0123456789abcdef'
  let h = 0
  for (let i = 0; i < seed.length; i++) {
    h = (h * 31 + seed.charCodeAt(i)) >>> 0
  }
  let out = ''
  for (let i = 0; i < 64; i++) {
    h = (h * 1103515245 + 12345) >>> 0
    out += chars[(h >> (i % 24)) & 15]
  }
  return out
}

export function shortHash(hash: string): string {
  return `${hash.slice(0, 4)}…${hash.slice(-4)}`
}

/**
 * A lightweight keyword-based heuristic that stands in for the future AI/NLP
 * service. This is intentionally simple and clearly labeled as demo output —
 * it is NOT a real threat-detection model.
 */
export function demoAnalyze(message: string): AnalysisResult {
  const text = message.toLowerCase().trim()

  const threatWords = [
    'kill',
    'hurt',
    'find you',
    'watching you',
    'come to your',
    'you will regret',
    'destroy you',
    'make you pay',
    'know where you live',
  ]
  const harassmentWords = [
    'stupid',
    'ugly',
    'worthless',
    'shut up',
    'nobody likes you',
    'pathetic',
    'loser',
    'idiot',
  ]
  const suspiciousWords = [
    'send me',
    'don\u2019t tell anyone',
    "don't tell anyone",
    'meet me alone',
    'give me your',
    'click this link',
    'verify your account',
    'or else',
  ]

  const hits = (list: string[]) => list.filter((w) => text.includes(w))
  const threatHits = hits(threatWords)
  const harassmentHits = hits(harassmentWords)
  const suspiciousHits = hits(suspiciousWords)

  if (threatHits.length > 0) {
    const critical = threatHits.length >= 2 || text.includes('kill')
    return {
      category: 'Threat',
      severity: critical ? 'Critical' : 'High',
      confidence: critical ? 0.96 : 0.91,
      explanation: critical
        ? 'The message contains language that may indicate a serious and direct threat to personal safety.'
        : 'The message contains language that may indicate intimidation or a direct threat.',
      indicators: [
        'Threatening language',
        'Intimidation',
        'Direct reference to personal safety',
      ],
      recommendedActions: ['protect', 'preserve', 'report'],
    }
  }

  if (harassmentHits.length > 0) {
    return {
      category: 'Harassment',
      severity: harassmentHits.length >= 2 ? 'High' : 'Suspicious',
      confidence: harassmentHits.length >= 2 ? 0.88 : 0.76,
      explanation:
        'The message contains language that may be demeaning, abusive, or intended to harass.',
      indicators: ['Demeaning language', 'Repeated hostility', 'Personal attacks'],
      recommendedActions: ['protect', 'preserve', 'report'],
    }
  }

  if (suspiciousHits.length > 0) {
    return {
      category: 'Suspicious',
      severity: 'Suspicious',
      confidence: 0.68,
      explanation:
        'Some language in this message may require attention, such as pressure, secrecy, or unusual requests.',
      indicators: ['Pressure or urgency', 'Requests for private information'],
      recommendedActions: ['preserve'],
    }
  }

  return {
    category: 'Safe',
    severity: 'Safe',
    confidence: 0.82,
    explanation: 'No significant risk indicators were detected in this message.',
    indicators: [],
    recommendedActions: ['none'],
  }
}

// --- Seed evidence records --------------------------------------------------

function build(
  id: string,
  category: EvidenceRecord['category'],
  severity: Severity,
  createdAt: string,
  message: string,
  analysis: AnalysisResult,
  protectedFlag = true,
): EvidenceRecord {
  const hash = demoHash(id + message)
  return {
    id,
    category,
    severity,
    createdAt,
    message,
    analysis,
    hash,
    integrity: 'verified',
    protected: protectedFlag,
    demo: true,
    audit: [
      { label: 'Message analyzed', timestamp: createdAt },
      { label: 'Evidence preserved', timestamp: createdAt },
      { label: 'Hash generated', timestamp: createdAt },
      { label: 'Record stored', timestamp: createdAt },
      { label: 'Integrity verified', timestamp: createdAt },
    ],
  }
}

export const seedEvidence: EvidenceRecord[] = [
  build(
    'SG-2026-00124',
    'Threat',
    'High',
    '2026-09-20T15:42:00',
    'I know where you live and you will regret ignoring me.',
    {
      category: 'Threat',
      severity: 'High',
      confidence: 0.94,
      explanation:
        'The message contains language that may indicate intimidation or a direct threat.',
      indicators: [
        'Threatening language',
        'Intimidation',
        'Direct reference to personal safety',
      ],
      recommendedActions: ['protect', 'preserve', 'report'],
    },
  ),
  build(
    'SG-2026-00123',
    'Harassment',
    'High',
    '2026-09-19T21:10:00',
    'Everyone thinks you are pathetic and worthless. Just give up.',
    {
      category: 'Harassment',
      severity: 'High',
      confidence: 0.88,
      explanation:
        'The message contains language that may be demeaning, abusive, or intended to harass.',
      indicators: ['Demeaning language', 'Repeated hostility', 'Personal attacks'],
      recommendedActions: ['protect', 'preserve', 'report'],
    },
  ),
  build(
    'SG-2026-00121',
    'Suspicious',
    'Suspicious',
    '2026-09-18T09:05:00',
    'Meet me alone and don\u2019t tell anyone where you are going.',
    {
      category: 'Suspicious',
      severity: 'Suspicious',
      confidence: 0.71,
      explanation:
        'Some language in this message may require attention, such as pressure or secrecy.',
      indicators: ['Pressure or urgency', 'Requests for secrecy'],
      recommendedActions: ['preserve'],
    },
  ),
]

export const demoActivity: ActivityEntry[] = [
  {
    id: 'a1',
    title: 'Threat detected',
    category: 'Threat',
    severity: 'High',
    time: 'Today',
    status: 'High Risk',
  },
  {
    id: 'a2',
    title: 'Harassment detected',
    category: 'Harassment',
    severity: 'Suspicious',
    time: 'Yesterday',
    status: 'Medium Risk',
  },
  {
    id: 'a3',
    title: 'Message protected',
    category: 'Suspicious',
    severity: 'Safe',
    time: '2 days ago',
    status: 'Protected',
  },
]

export const demoStats = {
  analyzed: 128,
  risks: 37,
  protected: 19,
  evidence: 12,
}
