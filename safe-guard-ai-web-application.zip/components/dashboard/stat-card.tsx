import type { ComponentType } from 'react'
import { cn } from '@/lib/utils'
import { Card } from '@/components/ui/card'

export function StatCard({
  label,
  value,
  icon: Icon,
  tone = 'primary',
  hint,
}: {
  label: string
  value: string | number
  icon: ComponentType<{ className?: string }>
  tone?: 'primary' | 'safe' | 'suspicious' | 'high'
  hint?: string
}) {
  const toneMap = {
    primary: 'bg-secondary text-primary',
    safe: 'bg-safe-surface text-safe',
    suspicious: 'bg-suspicious-surface text-suspicious',
    high: 'bg-high-surface text-high',
  }
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-medium text-muted-foreground">{label}</p>
          <p className="mt-2 text-3xl font-semibold tracking-tight text-foreground">
            {value}
          </p>
          {hint ? (
            <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
          ) : null}
        </div>
        <span
          className={cn(
            'inline-flex size-10 shrink-0 items-center justify-center rounded-xl',
            toneMap[tone],
          )}
        >
          <Icon className="size-5" />
        </span>
      </div>
    </Card>
  )
}
