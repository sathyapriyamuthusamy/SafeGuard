import { AlertTriangle, MessageSquareWarning, ShieldCheck } from 'lucide-react'
import type { ActivityEntry } from '@/lib/types'
import { RiskBadge } from '@/components/ui/risk-badge'
import { cn } from '@/lib/utils'

const iconFor: Record<
  ActivityEntry['category'],
  { icon: typeof AlertTriangle; cls: string }
> = {
  Threat: { icon: AlertTriangle, cls: 'bg-high-surface text-high' },
  Harassment: { icon: MessageSquareWarning, cls: 'bg-suspicious-surface text-suspicious' },
  Suspicious: { icon: ShieldCheck, cls: 'bg-secondary text-primary' },
  Safe: { icon: ShieldCheck, cls: 'bg-safe-surface text-safe' },
}

export function ActivityList({ items }: { items: ActivityEntry[] }) {
  return (
    <ul className="divide-y divide-border">
      {items.map((item) => {
        const { icon: Icon, cls } = iconFor[item.category]
        return (
          <li key={item.id} className="flex items-center gap-3 py-3.5 first:pt-0 last:pb-0">
            <span
              className={cn(
                'inline-flex size-9 shrink-0 items-center justify-center rounded-xl',
                cls,
              )}
            >
              <Icon className="size-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-foreground">
                {item.title}
              </p>
              <p className="text-xs text-muted-foreground">{item.time}</p>
            </div>
            <RiskBadge severity={item.severity} />
          </li>
        )
      })}
    </ul>
  )
}
