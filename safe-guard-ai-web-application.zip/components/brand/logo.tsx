import { cn } from '@/lib/utils'

export function Logo({
  className,
  showWordmark = true,
}: {
  className?: string
  showWordmark?: boolean
}) {
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <span className="relative inline-flex size-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-[#6d5ee0] shadow-sm shadow-primary/30">
        <svg
          viewBox="0 0 24 24"
          className="size-5 text-white"
          fill="none"
          aria-hidden="true"
        >
          <path
            d="M12 2.5 4.5 5.5v5.2c0 4.6 3.1 8.3 7.5 9.8 4.4-1.5 7.5-5.2 7.5-9.8V5.5L12 2.5Z"
            fill="currentColor"
            fillOpacity="0.18"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
          <path
            d="m8.7 12 2.2 2.2 4.4-4.4"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>
      {showWordmark ? (
        <span className="text-[0.95rem] font-semibold tracking-tight text-foreground">
          SafeGuard <span className="text-primary">AI</span>
        </span>
      ) : null}
    </span>
  )
}
