import Link from 'next/link'
import { Logo } from '@/components/brand/logo'
import { Button } from '@/components/ui/button'

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        <Link href="/" aria-label="SafeGuard AI home">
          <Logo />
        </Link>
        <nav className="hidden items-center gap-1 md:flex">
          <NavLink href="#how">How it works</NavLink>
          <NavLink href="#features">Features</NavLink>
          <NavLink href="#privacy">Privacy</NavLink>
        </nav>
        <div className="flex items-center gap-2">
          <Button
            render={<Link href="/dashboard" />}
            variant="ghost"
            size="lg"
            className="hidden sm:inline-flex"
          >
            Sign in
          </Button>
          <Button render={<Link href="/dashboard" />} size="lg" className="px-4">
            Open dashboard
          </Button>
        </div>
      </div>
    </header>
  )
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
    >
      {children}
    </a>
  )
}
