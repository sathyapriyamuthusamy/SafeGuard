import { ShieldCheck, MessageSquare, Fingerprint, Sparkles } from 'lucide-react'

// Abstract, non-photographic visual combining AI + Shield + Message + Security.
export function HeroVisual() {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-md">
      {/* soft gradient field */}
      <div className="absolute inset-0 rounded-[2.5rem] bg-gradient-to-br from-secondary via-card to-secondary/40" />
      <div className="absolute inset-0 rounded-[2.5rem] ring-1 ring-inset ring-primary/10" />

      {/* concentric protection rings */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="size-72 rounded-full border border-primary/10" />
      </div>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="size-52 rounded-full border border-primary/15" />
      </div>

      {/* central shield */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative flex size-28 items-center justify-center rounded-[1.75rem] bg-gradient-to-br from-primary to-[#6d5ee0] shadow-xl shadow-primary/30">
          <ShieldCheck className="size-14 text-white" />
          <span className="absolute -inset-2 -z-10 rounded-[2rem] bg-primary/20 blur-xl" />
        </div>
      </div>

      {/* floating chips */}
      <FloatChip
        className="left-3 top-10"
        icon={<MessageSquare className="size-4 text-primary" />}
        label="Message analyzed"
      />
      <FloatChip
        className="right-2 top-24"
        icon={<Sparkles className="size-4 text-primary" />}
        label="AI assessment"
      />
      <FloatChip
        className="bottom-10 left-6"
        icon={<Fingerprint className="size-4 text-safe" />}
        label="Integrity verified"
      />

      {/* connecting network dots */}
      <svg
        className="absolute inset-0 h-full w-full text-primary/25"
        aria-hidden="true"
      >
        <defs>
          <pattern
            id="dots"
            width="26"
            height="26"
            patternUnits="userSpaceOnUse"
          >
            <circle cx="1.5" cy="1.5" r="1.5" fill="currentColor" />
          </pattern>
        </defs>
        <rect
          width="40%"
          height="34%"
          x="58%"
          y="60%"
          fill="url(#dots)"
          opacity="0.5"
        />
      </svg>
    </div>
  )
}

function FloatChip({
  className,
  icon,
  label,
}: {
  className?: string
  icon: React.ReactNode
  label: string
}) {
  return (
    <div
      className={`absolute inline-flex items-center gap-2 rounded-full border border-border bg-card/90 px-3 py-1.5 text-xs font-medium text-foreground shadow-md shadow-primary/5 backdrop-blur ${className}`}
    >
      {icon}
      {label}
    </div>
  )
}
