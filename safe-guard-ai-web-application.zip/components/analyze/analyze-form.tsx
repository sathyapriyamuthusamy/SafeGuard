'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  ScanSearch,
  Loader2,
  ShieldCheck,
  FolderLock,
  Flag,
  Lock,
  RotateCcw,
  ArrowRight,
} from 'lucide-react'
import type { AnalysisResult } from '@/lib/types'
import { analyzeMessage } from '@/lib/api'
import { useStore } from '@/lib/store'
import { toast } from '@/components/ui/toast'
import { Button } from '@/components/ui/button'
import { Textarea, Label } from '@/components/ui/field'
import { Card, CardContent } from '@/components/ui/card'
import { DemoBadge } from '@/components/ui/risk-badge'
import { ResultCard } from '@/components/analyze/result-card'

const examples = [
  {
    label: 'Threatening message',
    text: 'I know where you live and you will regret ignoring me.',
  },
  {
    label: 'Harassment',
    text: 'Everyone thinks you are pathetic and worthless. Just give up.',
  },
  {
    label: 'Suspicious request',
    text: 'Meet me alone and don\u2019t tell anyone where you are going.',
  },
  {
    label: 'A friendly note',
    text: 'Hey! Great seeing you today, let\u2019s grab coffee next week.',
  },
]

export function AnalyzeForm() {
  const { preserveEvidence } = useStore()
  const [message, setMessage] = useState('')
  const [status, setStatus] = useState<'idle' | 'analyzing' | 'done'>('idle')
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [isProtected, setIsProtected] = useState(false)
  const [preserving, setPreserving] = useState(false)
  const [preservedId, setPreservedId] = useState<string | null>(null)

  async function handleAnalyze() {
    const trimmed = message.trim()
    if (!trimmed) {
      toast('Please enter a message first', { variant: 'warning' })
      return
    }
    setStatus('analyzing')
    setResult(null)
    setPreservedId(null)
    setIsProtected(false)
    try {
      const res = await analyzeMessage(trimmed)
      setResult(res)
      setStatus('done')
    } catch {
      setStatus('idle')
      toast('Something went wrong', {
        description: 'We could not analyze that message. Please try again.',
        variant: 'warning',
      })
    }
  }

  function handleReset() {
    setMessage('')
    setResult(null)
    setStatus('idle')
    setPreservedId(null)
    setIsProtected(false)
  }

  async function handlePreserve() {
    if (!result) return
    setPreserving(true)
    try {
      const record = await preserveEvidence({ message: message.trim(), analysis: result })
      setPreservedId(record.id)
      toast('Evidence preserved securely', {
        description: `Saved to your vault as ${record.id}.`,
        variant: 'success',
      })
    } catch {
      toast('Could not preserve evidence', { variant: 'warning' })
    } finally {
      setPreserving(false)
    }
  }

  function handleProtect() {
    setIsProtected(true)
    toast('Protection enabled', {
      description: 'This message has been shielded and flagged for follow-up.',
      variant: 'success',
    })
  }

  function handleReport() {
    toast('Report drafted', {
      description: 'A summary is ready to share with a trusted contact or authority.',
      variant: 'info',
    })
  }

  const actions = result?.recommendedActions ?? []

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="lg:col-span-3">
        <Card>
          <CardContent className="space-y-4 p-5 sm:p-6">
            <div className="flex items-center justify-between">
              <Label htmlFor="message">Message to analyze</Label>
              <DemoBadge />
            </div>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Paste the message or text that made you feel uncomfortable. Take your time — you're in a safe space here."
              rows={7}
              disabled={status === 'analyzing'}
              className="resize-none"
            />

            <div>
              <p className="mb-2 text-xs font-medium text-muted-foreground">
                Or try an example:
              </p>
              <div className="flex flex-wrap gap-2">
                {examples.map((ex) => (
                  <button
                    key={ex.label}
                    type="button"
                    disabled={status === 'analyzing'}
                    onClick={() => {
                      setMessage(ex.text)
                      setResult(null)
                      setStatus('idle')
                    }}
                    className="rounded-full border border-border bg-muted/50 px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:border-primary/40 hover:bg-secondary hover:text-secondary-foreground disabled:opacity-50"
                  >
                    {ex.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-2 sm:flex-row">
              <Button
                onClick={handleAnalyze}
                size="lg"
                disabled={status === 'analyzing'}
                className="flex-1"
              >
                {status === 'analyzing' ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Analyzing…
                  </>
                ) : (
                  <>
                    <ScanSearch className="size-4" />
                    Analyze message
                  </>
                )}
              </Button>
              {status !== 'idle' ? (
                <Button
                  onClick={handleReset}
                  variant="outline"
                  size="lg"
                  disabled={status === 'analyzing'}
                >
                  <RotateCcw className="size-4" />
                  Reset
                </Button>
              ) : null}
            </div>

            <p className="flex items-start gap-2 text-xs text-muted-foreground">
              <Lock className="mt-0.5 size-3.5 shrink-0" />
              Your messages are analyzed privately. In this demo, nothing is sent
              to a real server or stored permanently.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="lg:col-span-2">
        {status === 'analyzing' ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center gap-3 p-10 text-center">
              <span className="inline-flex size-12 items-center justify-center rounded-2xl bg-secondary text-primary">
                <Loader2 className="size-6 animate-spin" />
              </span>
              <p className="text-sm font-medium text-foreground">
                Analyzing your message
              </p>
              <p className="text-sm text-muted-foreground">
                Looking for signs of threats, harassment, or manipulation…
              </p>
            </CardContent>
          </Card>
        ) : result ? (
          <div className="space-y-4">
            <ResultCard result={result} />

            {actions.length > 0 && !actions.includes('none') ? (
              <Card>
                <CardContent className="space-y-3 p-5">
                  <p className="text-sm font-medium text-foreground">
                    Recommended next steps
                  </p>
                  <div className="flex flex-col gap-2">
                    {actions.includes('protect') ? (
                      <Button
                        onClick={handleProtect}
                        variant={isProtected ? 'outline' : 'default'}
                        className="w-full justify-start"
                        disabled={isProtected}
                      >
                        <ShieldCheck className="size-4" />
                        {isProtected ? 'Protection enabled' : 'Protect me from this'}
                      </Button>
                    ) : null}
                    {actions.includes('preserve') ? (
                      preservedId ? (
                        <Button
                          render={<Link href="/evidence" />}
                          variant="outline"
                          className="w-full justify-between"
                        >
                          <span className="flex items-center gap-2">
                            <FolderLock className="size-4" />
                            Saved as {preservedId}
                          </span>
                          <ArrowRight className="size-4" />
                        </Button>
                      ) : (
                        <Button
                          onClick={handlePreserve}
                          variant="secondary"
                          className="w-full justify-start"
                          disabled={preserving}
                        >
                          {preserving ? (
                            <Loader2 className="size-4 animate-spin" />
                          ) : (
                            <FolderLock className="size-4" />
                          )}
                          Preserve as evidence
                        </Button>
                      )
                    ) : null}
                    {actions.includes('report') ? (
                      <Button
                        onClick={handleReport}
                        variant="ghost"
                        className="w-full justify-start"
                      >
                        <Flag className="size-4" />
                        Prepare a report
                      </Button>
                    ) : null}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-safe/25 bg-safe-surface/40">
                <CardContent className="flex items-start gap-3 p-5">
                  <ShieldCheck className="mt-0.5 size-5 shrink-0 text-safe" />
                  <p className="text-sm text-safe-foreground">
                    This message looks safe. If it still made you uncomfortable,
                    trust your instincts — you can preserve or report anything.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          <Card className="h-full border-dashed">
            <CardContent className="flex h-full flex-col items-center justify-center gap-3 p-10 text-center">
              <span className="inline-flex size-12 items-center justify-center rounded-2xl bg-secondary text-primary">
                <ScanSearch className="size-6" />
              </span>
              <p className="text-sm font-medium text-foreground">
                Your results will appear here
              </p>
              <p className="text-sm text-muted-foreground">
                Enter a message and select analyze to see a calm, clear breakdown
                of any potential risks.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
