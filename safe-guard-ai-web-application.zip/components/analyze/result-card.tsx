import { AlertTriangle, CheckCircle2, ListChecks } from 'lucide-react'
import type { AnalysisResult } from '@/lib/types'
import { severityMeta } from '@/lib/severity'
import { cn } from '@/lib/utils'
import { Card, CardContent } from '@/components/ui/card'
import { RiskBadge } from '@/components/ui/risk-badge'

export function ResultCard({ result }: { result: AnalysisResult }) {
  const meta = severityMeta[result.severity]
  const isSafe = result.severity === 'Safe'
  const confidencePct = Math.round(result.confidence * 100)

  return (
    <Card className="overflow-hidden">
      <div className={cn('h-1.5 w-full', meta.dot)} />
      <CardContent className="space-y-5 p-5 pt-5 sm:p-6 sm:pt-6">
        <div className="flex flex-wrap items-center gap-3">
          <span
            className={cn(
              'inline-flex size-11 items-center justify-center rounded-xl',
              meta.surface,
              meta.accent,
            )}
          >
            {isSafe ? (
              <CheckCircle2 className="size-6" />
            ) : (
              <AlertTriangle className="size-6" />
            )}
          </span>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-semibold tracking-tight text-foreground">
                {result.category === 'Safe'
                  ? 'No risk detected'
                  : `${result.category} detected`}
              </h3>
              <RiskBadge severity={result.severity} />
            </div>
            <p className="text-sm text-muted-foreground">
              Model confidence: {confidencePct}%
            </p>
          </div>
        </div>

        <div>
          <div
            className="h-2 w-full overflow-hidden rounded-full bg-muted"
            role="progressbar"
            aria-valuenow={confidencePct}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label="Model confidence"
          >
            <div
              className={cn('h-full rounded-full transition-all', meta.dot)}
              style={{ width: `${confidencePct}%` }}
            />
          </div>
        </div>

        <div className="rounded-xl bg-muted/60 p-4">
          <p className="text-pretty text-sm leading-relaxed text-foreground">
            {result.explanation}
          </p>
        </div>

        {result.indicators.length > 0 ? (
          <div>
            <div className="mb-2 flex items-center gap-2 text-sm font-medium text-foreground">
              <ListChecks className="size-4 text-muted-foreground" />
              What we noticed
            </div>
            <ul className="flex flex-wrap gap-2">
              {result.indicators.map((indicator) => (
                <li
                  key={indicator}
                  className={cn(
                    'inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium',
                    meta.surface,
                    meta.text,
                    meta.border,
                  )}
                >
                  {indicator}
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </CardContent>
    </Card>
  )
}
