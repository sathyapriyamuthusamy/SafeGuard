import Link from 'next/link'
import { Settings } from 'lucide-react'
import { Logo } from '@/components/brand/logo'
import { Button } from '@/components/ui/button'

// Compact top bar shown only on mobile (the sidebar covers desktop).
export function AppTopbar() {
  return (
    <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-border bg-background/90 px-4 backdrop-blur md:hidden">
      <Link href="/" aria-label="SafeGuard AI home">
        <Logo />
      </Link>
      <Button
        render={<Link href="/settings" />}
        variant="ghost"
        size="icon"
        aria-label="Settings"
      >
        <Settings className="size-5" />
      </Button>
    </header>
  )
}
