import {
  LayoutDashboard,
  ScanSearch,
  ShieldCheck,
  FolderLock,
  LifeBuoy,
  Settings,
} from 'lucide-react'

export interface NavItem {
  href: string
  label: string
  icon: typeof LayoutDashboard
}

export const navItems: NavItem[] = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/analyze', label: 'Analyze', icon: ScanSearch },
  { href: '/protection', label: 'Protection', icon: ShieldCheck },
  { href: '/evidence', label: 'Evidence Vault', icon: FolderLock },
  { href: '/resources', label: 'Resources', icon: LifeBuoy },
  { href: '/settings', label: 'Settings', icon: Settings },
]

// Items shown in the mobile bottom tab bar (kept to five for space).
export const mobileNavItems: NavItem[] = navItems.filter((i) =>
  ['/dashboard', '/analyze', '/protection', '/evidence', '/resources'].includes(
    i.href,
  ),
)
