'use client'

import { useEffect, useState } from 'react'
import { CheckCircle2, Info, ShieldAlert, X } from 'lucide-react'
import { cn } from '@/lib/utils'

type ToastVariant = 'success' | 'info' | 'warning'

interface ToastItem {
  id: number
  title: string
  description?: string
  variant: ToastVariant
}

// Minimal module-level toast bus so any component can call toast() without
// wiring props through the tree.
let idSeq = 0
const listeners = new Set<(items: ToastItem[]) => void>()
let items: ToastItem[] = []

function emit() {
  for (const l of listeners) l([...items])
}

export function toast(
  title: string,
  opts: { description?: string; variant?: ToastVariant } = {},
) {
  const id = ++idSeq
  items = [...items, { id, title, description: opts.description, variant: opts.variant ?? 'success' }]
  emit()
  setTimeout(() => {
    items = items.filter((i) => i.id !== id)
    emit()
  }, 4200)
}

const variantMeta: Record<
  ToastVariant,
  { icon: typeof Info; className: string }
> = {
  success: { icon: CheckCircle2, className: 'text-safe' },
  info: { icon: Info, className: 'text-primary' },
  warning: { icon: ShieldAlert, className: 'text-suspicious' },
}

export function ToastViewport() {
  const [toasts, setToasts] = useState<ToastItem[]>([])

  useEffect(() => {
    listeners.add(setToasts)
    return () => {
      listeners.delete(setToasts)
    }
  }, [])

  function dismiss(id: number) {
    items = items.filter((i) => i.id !== id)
    emit()
  }

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[100] flex flex-col items-center gap-2 px-4 sm:bottom-6 sm:right-6 sm:left-auto sm:items-end">
      {toasts.map((t) => {
        const { icon: Icon, className } = variantMeta[t.variant]
        return (
          <div
            key={t.id}
            role="status"
            className="pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-xl border border-border bg-card p-3.5 shadow-lg shadow-primary/5 animate-in fade-in slide-in-from-bottom-2"
          >
            <Icon className={cn('mt-0.5 size-5 shrink-0', className)} />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-foreground">{t.title}</p>
              {t.description ? (
                <p className="mt-0.5 text-sm text-muted-foreground">
                  {t.description}
                </p>
              ) : null}
            </div>
            <button
              type="button"
              onClick={() => dismiss(t.id)}
              className="rounded-md p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              aria-label="Dismiss notification"
            >
              <X className="size-4" />
            </button>
          </div>
        )
      })}
    </div>
  )
}
