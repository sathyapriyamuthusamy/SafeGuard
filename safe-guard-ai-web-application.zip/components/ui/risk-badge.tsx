import { cn } from '@/lib/utils'
import { severityMeta } from '@/lib/severity'
import type { Severity } from '@/lib/types'

export function RiskBadge({
  severity,
  className,
  withDot = true,
}: {
  severity: Severity
  className?: string
  withDot?: boolean
}) {
  const meta = severityMeta[severity]
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium',
        meta.surface,
        meta.text,
        meta.border,
        className,
      )}
    >
      {withDot ? (
        <span className={cn('size-1.5 rounded-full', meta.dot)} />
      ) : null}
      {meta.label}
    </span>
  )
}

export function DemoBadge({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full border border-primary/25 bg-secondary px-2 py-0.5 text-[0.7rem] font-medium text-secondary-foreground',
        className,
      )}
    >
      Demo Data
    </span>
  )
}

export function IntegrityBadge({
  status,
  className,
}: {
  status: 'verified' | 'pending' | 'unverified'
  className?: string
}) {
  const map = {
    verified: {
      label: 'Integrity Verified',
      cls: 'bg-safe-surface text-safe-foreground border-safe/25',
      dot: 'bg-safe',
    },
    pending: {
      label: 'Verifying…',
      cls: 'bg-suspicious-surface text-suspicious-foreground border-suspicious/30',
      dot: 'bg-suspicious',
    },
    unverified: {
      label: 'Not Verified',
      cls: 'bg-muted text-muted-foreground border-border',
      dot: 'bg-muted-foreground',
    },
  }[status]
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium',
        map.cls,
        className,
      )}
    >
      <span className={cn('size-1.5 rounded-full', map.dot)} />
      {map.label}
    </span>
  )
}
