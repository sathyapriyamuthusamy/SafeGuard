'use client'

import Link from 'next/link'
import {
  ScanSearch,
  ShieldAlert,
  ShieldCheck,
  FolderLock,
  ArrowRight,
  Sparkles,
} from 'lucide-react'
import { useStore } from '@/lib/store'
import { demoActivity, demoStats } from '@/lib/demo-data'
import { PageHeader } from '@/components/app/page-header'
import { StatCard } from '@/components/dashboard/stat-card'
import { ActivityList } from '@/components/dashboard/activity-list'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card'
import { DemoBadge } from '@/components/ui/risk-badge'

export default function DashboardPage() {
  const { evidence } = useStore()

  return (
    <div className="space-y-8">
      <PageHeader
        title="Dashboard"
        description="A calm overview of your recent activity and protection status."
        action={
          <Button render={<Link href="/analyze" />} size="lg">
            <ScanSearch className="size-4" />
            Analyze a message
          </Button>
        }
      />

      <section
        aria-label="Overview statistics"
        className="grid grid-cols-2 gap-4 lg:grid-cols-4"
      >
        <StatCard
          label="Messages analyzed"
          value={demoStats.analyzed}
          icon={ScanSearch}
          tone="primary"
          hint="All time"
        />
        <StatCard
          label="Risks detected"
          value={demoStats.risks}
          icon={ShieldAlert}
          tone="high"
          hint="Flagged for review"
        />
        <StatCard
          label="Messages protected"
          value={demoStats.protected}
          icon={ShieldCheck}
          tone="safe"
          hint="Actively shielded"
        />
        <StatCard
          label="Evidence preserved"
          value={evidence.length}
          icon={FolderLock}
          tone="suspicious"
          hint="In your vault"
        />
      </section>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle>Recent activity</CardTitle>
              <CardDescription>
                Your latest analyses and protective actions.
              </CardDescription>
            </div>
            <DemoBadge />
          </CardHeader>
          <CardContent>
            <ActivityList items={demoActivity} />
          </CardContent>
        </Card>

        <Card className="overflow-hidden border-primary/20 bg-gradient-to-br from-secondary/70 to-card">
          <CardHeader>
            <span className="inline-flex size-10 items-center justify-center rounded-xl bg-primary/15 text-primary">
              <Sparkles className="size-5" />
            </span>
            <CardTitle className="mt-2">Feeling unsure about a message?</CardTitle>
            <CardDescription>
              Paste anything that made you uncomfortable. SafeGuard AI will help
              you understand it and decide what to do next — at your pace.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-2">
            <Button render={<Link href="/analyze" />} className="w-full">
              Start an analysis
              <ArrowRight className="size-4" />
            </Button>
            <Button
              render={<Link href="/resources" />}
              variant="ghost"
              className="w-full"
            >
              Find support resources
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
