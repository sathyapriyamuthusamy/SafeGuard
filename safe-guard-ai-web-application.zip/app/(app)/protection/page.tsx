'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  ShieldCheck,
  ShieldBan,
  Eye,
  FolderLock,
  BellRing,
  UserX,
  ArrowRight,
} from 'lucide-react'
import { useStore } from '@/lib/store'
import { toast } from '@/components/ui/toast'
import { PageHeader } from '@/components/app/page-header'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card'
import { Switch } from '@/components/ui/field'
import { Button } from '@/components/ui/button'
import { RiskBadge } from '@/components/ui/risk-badge'

interface Shield {
  key: string
  icon: typeof ShieldBan
  title: string
  description: string
  defaultOn: boolean
}

const shields: Shield[] = [
  {
    key: 'block',
    icon: ShieldBan,
    title: 'Auto-block flagged senders',
    description:
      'Automatically limit contact from sources tied to high-risk messages.',
    defaultOn: true,
  },
  {
    key: 'monitor',
    icon: Eye,
    title: 'Continuous monitoring',
    description:
      'Quietly watch for repeated patterns of harassment across messages.',
    defaultOn: true,
  },
  {
    key: 'preserve',
    icon: FolderLock,
    title: 'Auto-preserve evidence',
    description:
      'Securely save a tamper-evident copy whenever a serious threat is found.',
    defaultOn: false,
  },
  {
    key: 'alerts',
    icon: BellRing,
    title: 'Safety alerts',
    description:
      'Get a gentle heads-up when something needs your attention.',
    defaultOn: true,
  },
]

export default function ProtectionPage() {
  const { evidence } = useStore()
  const [toggles, setToggles] = useState<Record<string, boolean>>(
    () => Object.fromEntries(shields.map((s) => [s.key, s.defaultOn])),
  )

  const protectedItems = evidence.filter((e) => e.protected)
  const activeCount = Object.values(toggles).filter(Boolean).length

  function toggle(key: string, title: string, value: boolean) {
    setToggles((prev) => ({ ...prev, [key]: value }))
    toast(value ? `${title} on` : `${title} off`, {
      variant: value ? 'success' : 'info',
    })
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Protection Center"
        description="Configure the shields that quietly work in the background to keep you safe."
      />

      <Card className="overflow-hidden border-primary/20 bg-gradient-to-br from-secondary/60 to-card">
        <CardContent className="flex flex-col gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <span className="inline-flex size-14 items-center justify-center rounded-2xl bg-primary/15 text-primary">
              <ShieldCheck className="size-7" />
            </span>
            <div>
              <p className="text-lg font-semibold text-foreground">
                You&apos;re protected
              </p>
              <p className="text-sm text-muted-foreground">
                {activeCount} of {shields.length} shields active ·{' '}
                {protectedItems.length} messages actively protected
              </p>
            </div>
          </div>
          <Button render={<Link href="/analyze" />} size="lg">
            Analyze a message
            <ArrowRight className="size-4" />
          </Button>
        </CardContent>
      </Card>

      <section className="grid gap-4 sm:grid-cols-2">
        {shields.map((shield) => {
          const Icon = shield.icon
          const on = toggles[shield.key]
          return (
            <Card key={shield.key}>
              <CardContent className="flex items-start gap-4 p-5">
                <span
                  className={
                    on
                      ? 'inline-flex size-11 shrink-0 items-center justify-center rounded-xl bg-secondary text-primary'
                      : 'inline-flex size-11 shrink-0 items-center justify-center rounded-xl bg-muted text-muted-foreground'
                  }
                >
                  <Icon className="size-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-3">
                    <h3 className="text-sm font-semibold text-foreground">
                      {shield.title}
                    </h3>
                    <Switch
                      checked={on}
                      onCheckedChange={(v) => toggle(shield.key, shield.title, v)}
                    />
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {shield.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </section>

      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <div>
            <CardTitle>Protected messages</CardTitle>
            <CardDescription>
              Items currently shielded and being watched.
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          {protectedItems.length > 0 ? (
            <ul className="divide-y divide-border">
              {protectedItems.map((item) => (
                <li
                  key={item.id}
                  className="flex items-center gap-3 py-3.5 first:pt-0 last:pb-0"
                >
                  <span className="inline-flex size-9 shrink-0 items-center justify-center rounded-xl bg-secondary text-primary">
                    <UserX className="size-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-foreground">
                      {item.message}
                    </p>
                    <p className="text-xs text-muted-foreground">{item.id}</p>
                  </div>
                  <RiskBadge severity={item.severity} />
                </li>
              ))}
            </ul>
          ) : (
            <p className="py-6 text-center text-sm text-muted-foreground">
              No protected messages yet.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
