import { PageHeader } from '@/components/app/page-header'
import { AnalyzeForm } from '@/components/analyze/analyze-form'

export default function AnalyzePage() {
  return (
    <div className="space-y-8">
      <PageHeader
        title="Analyze a message"
        description="Paste anything that felt off. We'll help you understand what it might be and what you can do next."
      />
      <AnalyzeForm />
    </div>
  )
}
