import Link from 'next/link'
import {
  ScanSearch,
  ShieldCheck,
  FolderLock,
  MessageSquare,
  Fingerprint,
  Lock,
  Bell,
  FileText,
  ArrowRight,
  Sparkles,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Logo } from '@/components/brand/logo'
import { SiteHeader } from '@/components/landing/site-header'
import { HeroVisual } from '@/components/landing/hero-visual'
import { Card, CardContent } from '@/components/ui/card'

export default function LandingPage() {
  return (
    <div className="flex min-h-dvh flex-col bg-background">
      <SiteHeader />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="pointer-events-none absolute -top-32 left-1/2 size-[36rem] -translate-x-1/2 rounded-full bg-primary/10 blur-3xl" />
          <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 md:grid-cols-2 md:py-24">
            <div className="flex flex-col items-start">
              <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
                <Sparkles className="size-3.5 text-primary" />
                AI-assisted safety for online conversations
              </span>
              <h1 className="mt-5 text-pretty text-4xl font-semibold leading-[1.05] tracking-tight text-foreground sm:text-5xl md:text-6xl">
                Understand and act on{' '}
                <span className="text-primary">harmful messages</span>
              </h1>
              <p className="mt-5 max-w-md text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
                SafeGuard AI helps you analyze concerning messages, assess risk,
                and securely preserve evidence — so you can respond with clarity
                and confidence.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Button
                  render={<Link href="/analyze" />}
                  size="lg"
                  className="h-12 px-6 text-[0.95rem]"
                >
                  Analyze a message
                  <ArrowRight className="size-4" />
                </Button>
                <Button
                  render={<Link href="/dashboard" />}
                  variant="outline"
                  size="lg"
                  className="h-12 px-6 text-[0.95rem]"
                >
                  Open dashboard
                </Button>
              </div>
              <p className="mt-6 text-xs text-muted-foreground">
                Demonstration experience. Sample data shown throughout — not
                real analysis or legal advice.
              </p>
            </div>
            <div className="order-first md:order-last">
              <HeroVisual />
            </div>
          </div>
        </section>

        {/* How it works */}
        <section id="how" className="border-t border-border/60 bg-card/40">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-20">
            <SectionHeading
              eyebrow="How it works"
              title="Three steps to a safer conversation"
              description="A calm, guided flow from a concerning message to protected evidence."
            />
            <div className="mt-12 grid gap-5 md:grid-cols-3">
              <StepCard
                step="01"
                icon={ScanSearch}
                title="Analyze"
                description="Paste a concerning message. SafeGuard AI assesses risk, category, and the indicators behind the assessment."
              />
              <StepCard
                step="02"
                icon={ShieldCheck}
                title="Protect"
                description="Get clear, recommended next steps tailored to the severity — from blocking to reporting."
              />
              <StepCard
                step="03"
                icon={FolderLock}
                title="Preserve"
                description="Securely store a tamper-evident record with an integrity hash and full audit trail."
              />
            </div>
          </div>
        </section>

        {/* Features */}
        <section id="features" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-24">
          <SectionHeading
            eyebrow="Features"
            title="Everything you need to respond safely"
            description="Purpose-built tools that turn uncertainty into a clear, documented response."
          />
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            <FeatureCard
              icon={MessageSquare}
              title="Message analysis"
              description="Understand tone, intent, and risk level with an explainable assessment you can trust."
            />
            <FeatureCard
              icon={ShieldCheck}
              title="Risk scoring"
              description="Clear severity levels — Safe, Suspicious, High, and Critical — with confidence indicators."
            />
            <FeatureCard
              icon={Fingerprint}
              title="Evidence integrity"
              description="Each preserved record carries an integrity hash so its authenticity can be verified later."
            />
            <FeatureCard
              icon={FolderLock}
              title="Evidence vault"
              description="A single, organized place to store, search, and revisit preserved incidents."
            />
            <FeatureCard
              icon={Bell}
              title="Guided actions"
              description="Recommended next steps for each incident, from protecting yourself to reporting."
            />
            <FeatureCard
              icon={FileText}
              title="Shareable reports"
              description="Generate a clean summary of an incident to share with the people who can help."
            />
          </div>
        </section>

        {/* Privacy */}
        <section id="privacy" className="border-t border-border/60 bg-card/40">
          <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 sm:px-6 md:grid-cols-2 md:py-20">
            <div>
              <SectionHeading
                align="left"
                eyebrow="Privacy first"
                title="Built to respect your safety and privacy"
                description="SafeGuard AI is designed around discretion. Your messages are treated as sensitive, and preserved evidence stays under your control."
              />
              <ul className="mt-6 space-y-3">
                <PrivacyPoint text="Integrity hashing so records can be verified, not altered." />
                <PrivacyPoint text="Clear labeling of what is analysis versus advice." />
                <PrivacyPoint text="You decide what to preserve, protect, or delete." />
              </ul>
            </div>
            <Card className="bg-gradient-to-br from-secondary/60 to-card">
              <CardContent className="flex flex-col items-start gap-4 p-8">
                <span className="inline-flex size-12 items-center justify-center rounded-2xl bg-primary/15 text-primary">
                  <Lock className="size-6" />
                </span>
                <p className="text-lg font-medium leading-relaxed text-foreground">
                  {'"'}Preserving what happened shouldn&apos;t mean reliving it.
                  SafeGuard AI keeps the record safe so you can focus on staying
                  safe.{'"'}
                </p>
                <p className="text-sm text-muted-foreground">
                  A calmer way to document online harm.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* CTA */}
        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-24">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary to-[#6d5ee0] px-6 py-14 text-center shadow-xl shadow-primary/20 md:px-12">
            <div className="pointer-events-none absolute -right-16 -top-16 size-64 rounded-full bg-white/10 blur-2xl" />
            <h2 className="text-balance text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Ready to take the next step?
            </h2>
            <p className="mx-auto mt-4 max-w-lg text-pretty text-white/85">
              Start with a single message. SafeGuard AI will guide you through
              understanding it and keeping a secure record.
            </p>
            <div className="mt-8 flex justify-center">
              <Button
                render={<Link href="/analyze" />}
                size="lg"
                className="h-12 bg-white px-6 text-[0.95rem] text-primary hover:bg-white/90"
              >
                Analyze a message
                <ArrowRight className="size-4" />
              </Button>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border/60">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-8 sm:flex-row sm:px-6">
          <Logo />
          <p className="text-center text-xs text-muted-foreground sm:text-right">
            SafeGuard AI is a demonstration experience and does not provide
            legal, security, or emergency services. In an emergency, contact
            local authorities.
          </p>
        </div>
      </footer>
    </div>
  )
}

function SectionHeading({
  eyebrow,
  title,
  description,
  align = 'center',
}: {
  eyebrow: string
  title: string
  description?: string
  align?: 'center' | 'left'
}) {
  return (
    <div
      className={
        align === 'center'
          ? 'mx-auto max-w-2xl text-center'
          : 'max-w-xl text-left'
      }
    >
      <span className="text-xs font-semibold uppercase tracking-wider text-primary">
        {eyebrow}
      </span>
      <h2 className="mt-2 text-balance text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
        {title}
      </h2>
      {description ? (
        <p className="mt-3 text-pretty text-muted-foreground">{description}</p>
      ) : null}
    </div>
  )
}

function StepCard({
  step,
  icon: Icon,
  title,
  description,
}: {
  step: string
  icon: React.ComponentType<{ className?: string }>
  title: string
  description: string
}) {
  return (
    <Card className="relative">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <span className="inline-flex size-11 items-center justify-center rounded-xl bg-secondary text-primary">
            <Icon className="size-5" />
          </span>
          <span className="text-2xl font-semibold text-border">{step}</span>
        </div>
        <h3 className="mt-4 text-lg font-semibold tracking-tight">{title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          {description}
        </p>
      </CardContent>
    </Card>
  )
}

function FeatureCard({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ComponentType<{ className?: string }>
  title: string
  description: string
}) {
  return (
    <Card className="transition-colors hover:border-primary/30">
      <CardContent className="p-6">
        <span className="inline-flex size-11 items-center justify-center rounded-xl bg-secondary text-primary">
          <Icon className="size-5" />
        </span>
        <h3 className="mt-4 text-base font-semibold tracking-tight">{title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          {description}
        </p>
      </CardContent>
    </Card>
  )
}

function PrivacyPoint({ text }: { text: string }) {
  return (
    <li className="flex items-start gap-3">
      <span className="mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-full bg-safe-surface text-safe">
        <ShieldCheck className="size-3.5" />
      </span>
      <span className="text-sm text-foreground">{text}</span>
    </li>
  )
}
