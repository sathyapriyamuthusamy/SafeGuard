import type React from 'react'
import type { Metadata, Viewport } from 'next'
import { GeistSans } from 'geist/font/sans'
import { GeistMono } from 'geist/font/mono'
import { Analytics } from '@vercel/analytics/next'
import { StoreProvider } from '@/lib/store'
import { ToastViewport } from '@/components/ui/toast'
import './globals.css'

export const metadata: Metadata = {
  title: 'SafeGuard AI — Your intelligent shield against online harassment',
  description:
    'Detect potential online threats, protect yourself from harmful content, and securely preserve important digital evidence with SafeGuard AI.',
  generator: 'v0.app',
}

export const viewport: Viewport = {
  themeColor: '#8b7cf6',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable}`}>
      <body className="font-sans antialiased">
        <StoreProvider>
          {children}
          <ToastViewport />
        </StoreProvider>
        <Analytics />
      </body>
    </html>
  )
}
